import java.io.*;
/**
 * <p>Clase para crear una lista de numeros y ordenarlos de mayor a menor</p>
 * <p>La clase contiene un método para ordenar los elementos de una lista y
 * una método principal en la que introducir los datos</p>
 * 
 * @author David Conde Piñeiro
 * @since 29/04/2019
 * @version 1.0
 */
public class burbuja
{
//Métodos
/**
 *Método principal para la introduccion de los datos
*/
public static void main(String arg[]) throws IOException
{

BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
System.out.print("\n Ingrese Numero de Datos a Ingresar : ");
int tam = Integer.parseInt(in.readLine());
int arr[] = new int[tam];

System.out.println();

int j = 0;
for (int i = 0 ; i < arr.length;i++)
{
j+=1;
System.out.print("Elemento " + j + " : ");
arr[i] = Integer.parseInt(in.readLine());
}
burbuja(arr);
}//main
//Cosntructor
/**
 * Constructor para ordenar los datos de un Array de mayor a menor
 */
static void burbuja(int arreglo[])
{
for(int i = 0; i < arreglo.length - 1; i++)
{
for(int j = 0; j < arreglo.length - 1; j++)
{
if (arreglo[j] < arreglo[j + 1])
{
int tmp = arreglo[j+1];
arreglo[j+1] = arreglo[j];
arreglo[j] = tmp;
}
}
}
for(int i = 0;i < arreglo.length; i++)
{
System.out.print(arreglo[i]+"\n");
}
}//burbuja
}